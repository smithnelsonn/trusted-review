
import { useEffect, useState } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import Link from 'next/link';

export default function Reviews() {
  const [reviews, setReviews] = useState([]);

  useEffect(() => {
    const load = async () => {
      const snap = await getDocs(collection(db, 'reviews'));
      setReviews(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    };
    load();
  }, []);

  return (
    <div style={{ padding: 40 }}>
      <h1>Reviews</h1>
      {reviews.map(r => (
        <div key={r.id} style={{ marginBottom: 20 }}>
          <h3>{r.title}</h3>
          <p>{r.content}</p>
          <Link href={`/review/${r.id}`}>Open</Link>
        </div>
      ))}
    </div>
  );
}
