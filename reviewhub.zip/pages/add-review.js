
import { useState } from 'react';
import { addDoc, collection } from 'firebase/firestore';
import { db } from '../lib/firebase';

export default function AddReview() {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  const submit = async () => {
    await addDoc(collection(db, 'reviews'), {
      title,
      content,
      createdAt: new Date()
    });
    alert('Added');
  };

  return (
    <div style={{ padding: 40 }}>
      <h1>Add Review</h1>
      <input placeholder="Title" onChange={e => setTitle(e.target.value)} />
      <br/>
      <textarea placeholder="Content" onChange={e => setContent(e.target.value)} />
      <br/>
      <button onClick={submit}>Submit</button>
    </div>
  );
}
