
import Link from 'next/link';

export default function Home() {
  return (
    <div style={{ padding: 40 }}>
      <h1>ReviewHub</h1>
      <p>Shopify & Amazon Product Reviews</p>
      <Link href="/reviews">View Reviews</Link><br/>
      <Link href="/add-review">Add Review</Link>
    </div>
  );
}
