
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';

export default function ReviewPage() {
  const router = useRouter();
  const { id } = router.query;
  const [review, setReview] = useState(null);

  useEffect(() => {
    if (!id) return;
    const load = async () => {
      const snap = await getDoc(doc(db, 'reviews', id));
      setReview(snap.data());
    };
    load();
  }, [id]);

  if (!review) return <p>Loading...</p>;

  return (
    <div style={{ padding: 40 }}>
      <h1>{review.title}</h1>
      <p>{review.content}</p>
    </div>
  );
}
